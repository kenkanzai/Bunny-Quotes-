-- Bunny Quotes "Us" — run once in Supabase: SQL Editor > New query > paste > Run.
-- All tables are locked (RLS on, no policies). Only the "bunny" function can read or write them.

create table if not exists bq_items (
  id bigserial primary key,
  room text not null,
  device text not null,
  name text not null,
  kind text not null check (kind in ('bunny','heart')),
  path text,
  quote text,
  created_at timestamptz not null default now()
);
create index if not exists bq_items_room_id on bq_items (room, id desc);

create table if not exists bq_moods (
  room text not null,
  device text not null,
  name text not null,
  mood text not null,
  gif text,
  updated_at timestamptz not null default now(),
  primary key (room, device)
);

create table if not exists bq_subs (
  endpoint text primary key,
  room text not null,
  device text not null,
  sub jsonb not null,
  created_at timestamptz not null default now()
);
create index if not exists bq_subs_room on bq_subs (room);

create table if not exists bq_config (k text primary key, v text not null);

alter table bq_items  enable row level security;
alter table bq_moods  enable row level security;
alter table bq_subs   enable row level security;
alter table bq_config enable row level security;

-- Private storage for the bunny files (not public)
insert into storage.buckets (id, name, public)
values ('bunnies', 'bunnies', false)
on conflict (id) do nothing;
