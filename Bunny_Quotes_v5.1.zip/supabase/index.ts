// Bunny Quotes "Us" server — Supabase Edge Function named: bunny
// Turn OFF "Verify JWT" for this function. Access is checked by the room code instead.
import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const KEEP = 300; // bunnies kept per room (free storage is 1 GB)
const json = (d: unknown, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { ...CORS, "content-type": "application/json" } });
const bad = (m: string, s = 400) => json({ error: m }, s);
const okRoom = (r: unknown) => typeof r === "string" && /^[0-9a-f]{64}$/.test(r);
const okDevice = (d: unknown) => typeof d === "string" && /^[0-9a-zA-Z_-]{8,64}$/.test(d);
const clean = (t: unknown, n: number) => String(t ?? "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, n);

// VAPID keys are made once and kept in bq_config, so there is nothing to set up by hand.
let vapid: { publicKey: string; privateKey: string } | null = null;
async function readVapid() {
  const { data } = await sb.from("bq_config").select("k,v").in("k", ["vapid_public", "vapid_private"]);
  const m = Object.fromEntries((data ?? []).map((r) => [r.k, r.v]));
  return m.vapid_public && m.vapid_private ? { publicKey: m.vapid_public as string, privateKey: m.vapid_private as string } : null;
}
async function getVapid(): Promise<{ publicKey: string; privateKey: string }> {
  if (vapid) return vapid;
  let k: { publicKey: string; privateKey: string } | null = await readVapid();
  if (!k) {
    const made = webpush.generateVAPIDKeys();
    // first one written wins, then read back so every call uses the same pair
    await sb.from("bq_config").upsert([{ k: "vapid_public", v: made.publicKey }, { k: "vapid_private", v: made.privateKey }], { onConflict: "k", ignoreDuplicates: true });
    k = (await readVapid()) ?? made;
  }
  const pair = k!;
  webpush.setVapidDetails("https://kenkanzai.github.io/Bunny-Quotes-/", pair.publicKey, pair.privateKey);
  vapid = pair;
  return pair;
}

async function pushOthers(room: string, device: string, payload: Record<string, string>) {
  await getVapid();
  const { data } = await sb.from("bq_subs").select("endpoint,sub").eq("room", room).neq("device", device);
  await Promise.all((data ?? []).map(async (s) => {
    try { await webpush.sendNotification(s.sub, JSON.stringify(payload), { TTL: 86400, urgency: "high" }); }
    catch (e) {
      const code = (e as { statusCode?: number }).statusCode;
      if (code === 404 || code === 410) await sb.from("bq_subs").delete().eq("endpoint", s.endpoint);
    }
  }));
}

async function trim(room: string) {
  const { data } = await sb.from("bq_items").select("id,path").eq("room", room).order("id", { ascending: false }).range(KEEP, KEEP + 200);
  if (!data?.length) return;
  const paths = data.map((r) => r.path).filter(Boolean) as string[];
  if (paths.length) await sb.storage.from("bunnies").remove(paths);
  await sb.from("bq_items").delete().in("id", data.map((r) => r.id));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return bad("POST only", 405);
  const url = new URL(req.url);
  try {
    // Send a bunny: the file is the request body, details are in the link.
    if (url.searchParams.get("action") === "bunny") {
      const room = url.searchParams.get("room"), device = url.searchParams.get("device");
      if (!okRoom(room) || !okDevice(device)) return bad("room");
      const name = clean(url.searchParams.get("name"), 30) || "Someone";
      const quote = clean(url.searchParams.get("quote"), 120);
      const type = req.headers.get("content-type") || "";
      if (type !== "image/gif" && type !== "image/jpeg") return bad("type");
      const body = new Uint8Array(await req.arrayBuffer());
      if (!body.length || body.length > 8_000_000) return bad("size");
      const path = `${room}/${crypto.randomUUID()}.${type === "image/gif" ? "gif" : "jpg"}`;
      const up = await sb.storage.from("bunnies").upload(path, body, { contentType: type });
      if (up.error) return bad("upload", 500);
      const ins = await sb.from("bq_items").insert({ room, device, name, kind: "bunny", path, quote }).select("id").single();
      if (ins.error) return bad("save", 500);
      await pushOthers(room!, device!, { title: `${name} sent you a bunny 🐰`, body: quote || "Open to see it", url: "./#us" });
      await trim(room!);
      return json({ id: ins.data.id });
    }

    const b = await req.json();
    if (b.action === "vapid") return json({ key: (await getVapid()).publicKey });
    if (!okRoom(b.room) || !okDevice(b.device)) return bad("room");
    const name = clean(b.name, 30) || "Someone";

    if (b.action === "sync") {
      const [items, moods] = await Promise.all([
        sb.from("bq_items").select("id,device,name,kind,path,quote,created_at").eq("room", b.room).order("id", { ascending: false }).limit(50),
        sb.from("bq_moods").select("device,name,mood,gif,updated_at").eq("room", b.room),
      ]);
      const list = items.data ?? [];
      const paths = list.map((i) => i.path).filter(Boolean) as string[];
      const urls: Record<string, string> = {};
      if (paths.length) {
        const s = await sb.storage.from("bunnies").createSignedUrls(paths, 3600);
        (s.data ?? []).forEach((x) => { if (x.path && x.signedUrl) urls[x.path] = x.signedUrl; });
      }
      return json({
        items: list.map((i) => ({ id: i.id, mine: i.device === b.device, name: i.name, kind: i.kind, quote: i.quote, at: i.created_at, url: i.path ? urls[i.path] ?? null : null })),
        moods: (moods.data ?? []).map((m) => ({ mine: m.device === b.device, name: m.name, mood: m.mood, gif: m.gif, at: m.updated_at })),
      });
    }
    if (b.action === "heart") {
      const ins = await sb.from("bq_items").insert({ room: b.room, device: b.device, name, kind: "heart" }).select("id").single();
      if (ins.error) return bad("save", 500);
      await pushOthers(b.room, b.device, { title: `${name} is thinking of you 💗`, body: "Tap to send one back", url: "./#us" });
      return json({ id: ins.data.id });
    }
    if (b.action === "mood") {
      const mood = clean(b.mood, 20), gif = clean(b.gif, 400);
      if (!mood || (gif && !gif.startsWith("https://"))) return bad("mood");
      const r = await sb.from("bq_moods").upsert({ room: b.room, device: b.device, name, mood, gif: gif || null, updated_at: new Date().toISOString() });
      if (r.error) return bad("save", 500);
      return json({ ok: true });
    }
    if (b.action === "subscribe") {
      const s = b.sub;
      if (!s || typeof s.endpoint !== "string" || !s.endpoint.startsWith("https://") || !s.keys?.p256dh || !s.keys?.auth) return bad("sub");
      const r = await sb.from("bq_subs").upsert({ endpoint: s.endpoint, room: b.room, device: b.device, sub: { endpoint: s.endpoint, keys: { p256dh: s.keys.p256dh, auth: s.keys.auth } } });
      if (r.error) return bad("save", 500);
      return json({ ok: true });
    }
    if (b.action === "unsubscribe") {
      await sb.from("bq_subs").delete().eq("device", b.device).eq("room", b.room);
      return json({ ok: true });
    }
    return bad("action");
  } catch (_e) {
    return bad("server", 500);
  }
});
