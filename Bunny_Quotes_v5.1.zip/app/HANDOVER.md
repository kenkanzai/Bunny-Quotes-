# Bunny Quotes — Handover

Read this first, before any change to the app.

App file: `index.html` (was `bunny-quotes.html`; opens in Chrome on phone or PC).
App files (v5): `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`.
Us server files (v5, set up once in Supabase, not on GitHub): `supabase/setup.sql`, `supabase/index.ts` (Edge Function named `bunny`).
Live link: https://kenkanzai.github.io/Bunny-Quotes-/ (GitHub repo kenkanzai/Bunny-Quotes-, Pages from main / root).
Owner: Christopher.
Last update: 4 November 2026 (v5.1).

---

## 1. What the app is for

Find existing cute bunny GIFs, stickers and pictures from the internet, write a quote **directly on** the GIF or picture, and send it to someone through Messenger, WhatsApp or any message app.

Since v5, the **Us** tab lets two phones share a private room: send bunnies straight to each other, send a "thinking of you" heart, and share today's mood. For a couple who are far from each other.

## 2. Owner's rules for this app (do not break)

1. Bunnies come from the internet (existing GIFs, stickers, pictures). **Never draw or create bunnies.**
2. The main source of bunnies is always the internet. **Never** make the user add his own GIFs or pictures to get bunnies. His own photo is an optional extra (Use my photo), added at his request in v4.2.
3. The quote is written **on** the GIF or picture itself. A GIF must stay animated after the quote is added.
4. The quote must **match the meaning** of the bunny (same theme). See section 5.
5. Send must reach Messenger, WhatsApp and any message app (phone share menu).
6. Quotes on the GIF use the plain apostrophe `'`, not the curly one `’` (the Cute font has no curly apostrophe and shows a gap).
7. General working rules:
   - If his message has a question, answer it first and wait for his reply before changing anything.
   - Change only what he asks. Nothing extra.
   - If a request is unclear, ask one line before changing anything.
   - After every change, say what it was checked against. Say so if it could not be tested.
   - Give a direct answer first, then detail.

## 3. Screens

**Today**
- One theme per day: 5–11 am Good morning, 9 pm–5 am Good night, other hours rotate through the other 8 groups by day.
- Shows a GIPHY GIF for that theme with a quote from the same group. Theme name shows after the date.
- Buttons: Another bunny (same theme), Another quote (same group), Edit, Send.
- Today's bunny is cached for the day so opening the app does not use searches.

**Find**
- Search box. A word without "bunny" or "rabbit" gets "bunny " added (e.g. "good morning" → "bunny good morning").
- 20 topic buttons, 3 types: GIFs, Stickers, Photos (Photos need a Pexels key).
- Loads 50 at a time, more load on scroll (Load more button as fallback). No repeats in one list. GIPHY stops at about 500 results per search.
- **Use my photo:** opens camera, gallery or files. His own photo or GIF goes into the same Editor. Own GIFs stay animated. Big photos are reduced to 1600 px on the longest side so they send easily. No quote theme is set for own photos; the last quote group is used.
- Tap a bunny → Editor.

**Editor**
- Live preview with the quote on the bunny. The preview shows exactly what the file will look like (text is drawn with the same rules as the file).
- Bunny size (v5.1): zoom slider (1x–3x) and Reset. When zoomed in, drag the bunny to move it. The saved/sent file uses the same crop. Swiping on the picture scrolls the page only at 1x.
- Quote: 10 groups, Another quote, or type your own (max 500 characters; line breaks are kept, for poems).
- Search quotes and poems (v5.1): search box, results in All / Quotes / Poems with counts, 30 at a time (Show more). Tap a result to put it in the quote box. "Add the author's name" (on by default) adds a last line "- Author". Sources: see section 4.
  - Poems: up to 12 lines → whole poem; longer → the verse that holds the search word (max 8 lines).
- Layout (v5.1): On bunny (text with outline, as before), Box (soft box behind the text), Card (bunny on top, text on a color panel under it; Top puts the panel above). In Card, Mid is off and Color is the card color (text turns dark or white automatically). A tip shows when text has more than 5 lines and Card is not on.
- Font: Cute (Gaegu), Round (Fredoka), Script (Pacifico), Hand (Patrick Hand), Bold (Nunito).
- Size and font shrink automatically so long text fits (On bunny / Box: within the picture; Card: panel up to 1.3x the picture height).
- Color: white, pink, yellow, mint, blue, plum, black. Outline turns dark or white automatically.
- Size: S, M, L. Place: Top, Middle, Bottom. Last style (incl. layout) is remembered and also used on Today.
- Save (downloads the file) and Send (opens the share menu; if not available, saves to Downloads with a message).

**Us** (v5)
- Join: your name + room code (same code on both phones, at least 8 characters). The second phone can join by the invite link (fills in server and code; she only types her name).
- Partner's mood card(s) and your own. My mood: Happy, Love, Miss you, Tired, Sad, Excited. Each mood picks a matching GIPHY bunny (search: bunny happy, bunny love, bunny miss you, sleepy bunny, bunny sad, bunny dance). If GIPHY fails, the emoji shows instead.
- 💗 Thinking of you: sends a heart.
- 🔔 Alerts: phone notification when a bunny or heart arrives (not for moods). Asked right after joining. Tap again to turn off.
- Messages: last 50, newest first. Yours on the right. Bunnies have Save.
- Copy invite link, Leave room.
- Badge on the Us tab counts new bunnies/hearts from the other phone. The app checks every 20 s while open, and when it comes back to the screen.
- **💌 Send to [her name]** button on Today and in the Editor (shown only after joining). Sends the same file as Send (quote on the GIF/photo). Works for own photos too.

**Settings**
- GIPHY key and optional Pexels key.
- Us server link (the Supabase function link).

## 4. Keys and limits

- GIPHY beta key: free, **100 searches per hour**. Created on developers.giphy.com under the name "Ken" (platform Web).
- The key is built into the file (`DEFAULT_GIPHY` in the script). Anyone with the file uses the same 100 per hour. If it leaks: delete it on the GIPHY dashboard, create a new one, paste it in Settings or replace `DEFAULT_GIPHY`.
- Pexels key: optional, for Photos only. Not set yet.
- When the hourly limit is reached, the app shows: "You've used this hour's 100 searches."
- Mood changes also use GIPHY searches (1 each).

**Quote and poem search (v5.1, no keys, does not use GIPHY searches)**

| Source | What | Notes |
|---|---|---|
| App's own 80 quotes | quotes | shown first |
| GitHub: JamesFT/Database-Quotes-JSON (pinned commit 418d77f) | ~1,600 unique quotes | file is Windows-1252, decoded as such |
| GitHub: dwyl/quotes (main) | ~1,600 quotes | mostly the same as JamesFT; duplicates removed |
| dummyjson.com/quotes | ~1,450 quotes | |
| Wikiquote (en.wikiquote.org API) | top 2 pages for the word (a topic page like "Love" or a person's page), up to 60 quotes each | widest source |
| PoetryDB (poetrydb.org) | classic public-domain poems: up to 40 by lines, 20 by title, 20 by author | |

- Quote files load once per app session (about 1 MB in total), then search is instant.
- If a source is down, the others still show. If all are down: "Can't reach the internet. Showing the app's own quotes only."
- Curly apostrophes from sources are changed to `'` (rule 6).

**Us server (Supabase, free plan, no card)**
- One Edge Function `bunny`, "Verify JWT" turned **off**. Access is checked by the room: the app sends SHA-256 of `bunny-quotes|` + the room code (lowercase), never the code itself.
- Tables `bq_items`, `bq_moods`, `bq_subs`, `bq_config`: RLS on, no policies, so only the function can use them. Files in private storage bucket `bunnies` (signed links valid 1 hour).
- Alert (VAPID) keys are made by the function on first use and kept in `bq_config`. Nothing to paste by hand.
- Keeps the last 300 bunnies per room; older ones are deleted (free storage is 1 GB). Max 8 MB per bunny.
- Free projects pause after 7 days with no use; restore from the Supabase dashboard.

## 5. Quote ↔ bunny matching

10 quote groups, 8 quotes each (80 total): Good morning, Good night, Love, Miss you, Hi, Cheer up, Thank you, Sorry, Birthday, Funny.

Today uses these GIPHY searches per group:

| Group | Search |
|---|---|
| Good morning | bunny good morning |
| Good night | bunny good night |
| Love | bunny love |
| Miss you | bunny miss you |
| Hi | bunny hi |
| Cheer up | bunny hug |
| Thank you | bunny thank you |
| Sorry | bunny sorry |
| Birthday | bunny birthday |
| Funny | funny bunny |

Find topics → group (by keywords in the search word):

| Topic | Group |
|---|---|
| bunny hi | Hi |
| bunny love, bunny kiss | Love |
| bunny hug, bunny sad | Cheer up |
| bunny good morning | Good morning |
| bunny good night, sleepy bunny | Good night |
| bunny miss you, bunny bye | Miss you |
| bunny thank you | Thank you |
| bunny sorry | Sorry |
| bunny birthday | Birthday |
| bunny dance, bunny happy, bunny eating | Funny |
| cute bunny, kawaii bunny, baby bunny, fluffy rabbit | from the GIF's own title; "Hi" if the title has no clue |

Limit: matching depends on how GIPHY tags its GIFs. A GIF may sometimes not fit; Another bunny gives a new one.

## 6. How the quote is written on a GIF

- Download the GIF (GIPHY `downsized_medium`, else `downsized`, else `original`).
- Read every frame (gifuct-js), draw the frame, draw the quote, rebuild the GIF (gifenc). Max width 480 px. Transparent stickers get a white background.
- Photos (Pexels `large`): draw picture + quote, save as JPG.
- Both libraries are bundled inside the HTML file (no internet needed for them).

## 7. Where things are in the code

| Part | Look for |
|---|---|
| Quotes | `const QUOTES=` |
| Topic buttons | `const TOPICS=` |
| Group → Today search | `const TOPIC_OF=` |
| Search word → group | `const KEYWORDS=` |
| Fonts, colors, sizes | `const FONTS=`, `COLORS`, `SIZES` |
| Built-in GIPHY key | `const DEFAULT_GIPHY=` |
| Text layout (screen and file) | `plan` (size, lines), `paint` (draws text, box, card) |
| Preview | `stage`, `paintStage` |
| Bunny zoom/move | `cropOf`, `zoom`, `zoomReset`, `drag` (item.crop = {z, fx, fy}) |
| Quote/poem search | `QSRC`, `quoteBank`, `wikiSearch`, `poemSearch`, `excerpt`, `quoteSearch`, `showQ` |
| File with quote | `makeFile` |
| Send / Save | `sendItem`, `download` |
| Use my photo | `ownBtn`, `ownFile` |

| Us tab (all) | `/* ---------- Us:` block, `MOODS`, `syncUs`, `sendUs`, `renderUs` |
| Alerts | `subscribe`, `alertState`, `askAlerts`; `push` and `notificationclick` in `sw.js` |
| Invite link | `inviteBtn`, `readInvite` |

Saved on the device (browser storage): `giphyKey`, `pexelsKey`, `style`, `todayCache`, `usServer`, `usName`, `usRoom`, `usCode`, `usDevice`, `usPartner`, `usSeen`.

## 8. Not tested yet

- Send on a real phone (share menu with WhatsApp / Messenger). Only PC screens have been seen.
- Photos tab (no Pexels key yet).
- Use my photo: camera and gallery on a real phone.
- Writing the quote on a live GIPHY GIF was not run in the build workspace (no internet there). It needs a check on the device.
- Search (v5.1): run in a browser against stand-in answers shaped like each source. The real GitHub quote files were downloaded and used in the test (both load and decode). dummyjson, Wikiquote and PoetryDB were **not reached live** from the build workspace; the Wikiquote page reader was tested on a sample page in Wikiquote's format. Needs a check on the phone.
- Layout and zoom (v5.1): checked in a phone-size browser: On bunny, Box, Card (top/bottom), zoom + drag; saved GIF stayed animated (6 of 6 frames) with crop and card. Real Google fonts were not loaded in the test.
- Dashes (—) in poems/quotes: not checked whether every font has them.
- Us (v5): tested with two phone screens against a stand-in server that answers like the `bunny` function: join, invite link, mood, heart, Send to Us (own photo), badge, feed. **Not yet run against real Supabase.** The function passed a type check in Deno 2, and the alert encryption library (web-push) was run in Deno 2. Real phone alerts not tested yet.

## 9. Version history

| Version | Change | Owner's response |
|---|---|---|
| v1 | Drawn bunnies with quotes | Rejected: wanted real GIFs from the web |
| v2 | User adds own GIFs/pictures | Rejected: wanted GIFs from the internet |
| v3 | GIPHY search, quote written on GIF, Send/Save | Accepted; key setup done |
| v3.1 | GIPHY key built into the file | — |
| v3.2 | Apostrophe gap fixed ("it' s" → "it's") | — |
| v4 | Refine all: layout, quote style options, 80 quotes in 10 groups, 20 topics, scroll loading | — |
| v4.1 | Quote matches the bunny's theme (Today and Find) | — |
| v4.2 | Use my photo: quote on his own photo or GIF | Requested |
| v4.3 | Installable app (PWA): manifest, service worker, 🐰 icon; 2 lines added to the HTML. App features unchanged | Requested |
| v5 | Us tab for two phones: Send to her, Thinking-of-you heart, Today's mood, alerts (Supabase). Other screens unchanged except the new Send to Us button and Us server link in Settings | Requested |
| v5.1 | Search quotes and poems online (6 sources); Layout: On bunny / Box / Card; bunny zoom and move; quote box up to 500 characters with line breaks. Other screens unchanged | Requested |
